package JoS.JAVAProjects;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;


public class MainDriver{
	static Calendar cal = Calendar.getInstance();
	public void DriverMain (Object[] strObj) throws ParseException
	{
		DriveMain(strObj[0].toString(),strObj[1].toString(),strObj[2].toString(),strObj[3].toString(),strObj[4].toString(),strObj[5].toString());
	}
	public void DriveMain (String strRunID, String pLocator, String pSubLocator, String pTestSet, String pTestID, String pBrowserType) throws ParseException {
		long lStartTime = new Date().getTime();
		
		ApplicationParams gOBJ=new ApplicationParams();//.GetObject().LoadSettings();
		gOBJ.LoadSettings();
		DebugInterface di=new DebugInterface(gOBJ);
		System.out.println("Vinit : Test ID is "+ pTestID);
		//new KillProcess().CleanUpProcess();
		gOBJ.setTestID(pTestID);
		gOBJ.setgNumRunID(strRunID);
		gOBJ.setgSubLocator(pSubLocator);
		gOBJ.setgTestSet(pTestSet);
		gOBJ.setgBrowserType(pBrowserType);
		gOBJ.setgStrReleaseFolder(pLocator);
		gOBJ.setgStrAutomationPathNew(gOBJ.getgStrAutomationPath() + "\\Results\\" + gOBJ.getgStrReleaseFolder() + "\\");
		//To check if the pLocator path is not existing in file system.
		File file = new File(gOBJ.getgStrAutomationPathNew());
		
		if (!file.exists()) {
			if (file.mkdir()) {
				System.out.println ("Test suite path does not exist, hence created! = " + gOBJ.getgStrAutomationPathNew());
			} else {
				System.out.println ("Test suite path exists! = " + gOBJ.getgStrAutomationPathNew());
			}
		}
		
		
		//Any logs to debug file will be done only after calling Load automation interfaces
		new ConfigurationManager(gOBJ).LoadAutomationInterfaces();
		di.Debug ("Going for InitializeTestReport()");
		//MainDriver.InitializeTestReport();		
		di.Debug ("Going for ExecuteAutomation()");
		new ExecuteAutomation(gOBJ).GlobalIterationRun();

		long lEndTime = new Date().getTime();
		long ExecutionTime = lEndTime - lStartTime;
		di.Debug ("Test Execution time in seconds (long) : " + (double)ExecutionTime/1000);
		di.Debug ("Test Execution time in seconds : " + String.valueOf((double)ExecutionTime/1000));
		//new HtmlReportInterface(gOBJ).HtmlFooter(String.valueOf((double)ExecutionTime/1000) + " secs", gOBJ.getTestSteppassCount(), gOBJ.getTestStepFailCount());
		if(gOBJ.rep!=null)
			gOBJ.rep.addTestLogFooter(String.valueOf((double)ExecutionTime/1000));
		DebugInterface ZdF = new DebugInterface(gOBJ);
		try {
			ZdF.ZipDebugFolder();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		new DB_Handler().CloseConnection();
		gOBJ.DestroyObject();
	//	new KillProcess().CleanUpProcess();
	}
	
}

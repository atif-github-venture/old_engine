package JoS.JAVAProjects.Reporting;

public enum Status
{
  FAIL,  WARNING,  PASS,  SCREENSHOT,  DONE,  DEBUG;
}

package JoS.JAVAProjects;


public class KillProcess {/*
	private  final String KILL = "taskkill /F /IM ";

	public void CleanUpProcess(){
		try {
			killProcess("IEDriverServer.exe");
			killProcess("conhost.exe");
			//killProcess("chromedriver.exe");
			killProcess("iexplore.exe");
			killProcess("firefox.exe");
			//killProcess("chrome.exe");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public  void killProcess(String serviceName) throws Exception {
		Runtime.getRuntime().exec(KILL + serviceName);
	}*/
}

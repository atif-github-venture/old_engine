package main.java.util;
/**
 * The Logger class is used to log
 *
 * @author Shilpashree_V
 * @version 1.0
 * @since February 2015
 * 
 */
public class Logger {

}

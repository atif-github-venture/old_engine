package jos.queue.system;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * Hello world!
 *
 */
class QueueClass
{
	class WorkerThread implements Runnable {
		private org.apache.log4j.Logger log;
		private String strProjectDBName,locator, sublocator,test_set, browsertype,email_setting;

		public WorkerThread(String strProjectDBNameTemp, String locatorTemp, String sublocatorTemp, String test_setTemp, String browsertypeTemp, String email_settingTemp){
			this.strProjectDBName = strProjectDBNameTemp;
			this.locator = locatorTemp;
			this.sublocator = sublocatorTemp;
			this.test_set = test_setTemp;
			this.browsertype = browsertypeTemp;
			this.email_setting = email_settingTemp;
			log=Logger.getLogger(getClass());

		}

		public synchronized void run() {
			System.out.println(Thread.currentThread().getName()+" Started ");
			log.info("Reading properties");
			//readproperties();
			DB_Handler con = new DB_Handler();
			System.out.println("Project DB Name: " + strProjectDBName);
						
			System.out.println("insert into current_execution_request (dbName, locator, sublocator, test_set, browsertype, email_setting) values ('" + strProjectDBName + "','" + locator + "','" + sublocator + "','" + test_set + "','" + browsertype + "','" + email_setting + "');");
			boolean QueryInsertRequest = con.ExecuteInsertQuery("current_execution_request (dbName, locator, sublocator, test_set, browsertype, email_setting) values ('" + strProjectDBName + "','" + locator + "','" + sublocator + "','" + test_set + "','" + browsertype + "','" + email_setting + "');");

			if (QueryInsertRequest){
				ResultSet rExecutionStatus = con.ExecuteSelectQuery("*", "queue_execution_status;");		
				try {
					if (rExecutionStatus.next()){
						String status = rExecutionStatus.getString("Status");
						log.info("Status: " + status);
						if (status.equalsIgnoreCase("OFF")){
							//con.ExecuteInsertQuery("Delete from queue_execution_status;");
							con.ExecuteUpdateQuery("queue_execution_status SET Status='ON';");
							log.info("CALL: Switch ON the execution by calling another jar.");
							//wake up another jar for executions
							CallQueueExecutionJar();
							log.info("BACK: Switch ON the execution by calling another jar");
							log.info("____________________________________________________");
							log.info("____________________________________________________");
						}
					}else{
						con.ExecuteInsertQuery("queue_execution_status SET Status='ON';");
						//wake up another jar for executions
						CallQueueExecutionJar();
						log.info("BACK: Switch ON the execution by calling another jar");
						log.info("____________________________________________________");
						log.info("____________________________________________________");
					}
				} catch (SQLException e) {
					log.info("Exception: " + e);
					e.printStackTrace();
					con.CloseConnection();
				}
			}

			con.CloseConnection();
			System.out.println(Thread.currentThread().getName()+" End.");
		}


		@Override
		public String toString(){
			return "";
		}
	}
	private Logger log=null;

	QueueClass(){
		String log4jConfPath = "log4j.properties";
		PropertyConfigurator.configure(log4jConfPath);
		log=Logger.getLogger(getClass());
	}


	public void create_queue(String strProjDBName, String locator, String sublocator, String test_set, String browsertype, String email_setting){
		System.out.println("Thread Started under create_queue");
		WorkerThread t= new WorkerThread(strProjDBName, locator, sublocator, test_set,browsertype, email_setting);
		Thread t1=new Thread(t);
		t1.start();
		System.out.println("Thread ended under create_queue");
		//t1.join();
	}


	@SuppressWarnings("resource")
	public void CallQueueExecutionJar(){
		try {
			String strFolderPath="";
			try {
				strFolderPath="file:\\" + new File (".").getCanonicalPath() + "\\QueueExecution.jar";
			} catch (IOException e) {
				log.info("IOException: " + e.getMessage());
			}
			//strFolderPath="file:\\F:\\CorpHQ\\CHQ Performance Engineering\\External\\JoS-PolicyCenter_v8\\Jos_UI\\QueueExecution.jar";
			strFolderPath=strFolderPath.replace("\\","/");
			URL[] classLoaderUrls = new URL[]{new URL(strFolderPath)};
			URLClassLoader urlClassLoader = new URLClassLoader(classLoaderUrls);
			Class<?> cls = urlClassLoader.loadClass("jos.queue.testset.execution.CallQueueExecution");
			Constructor<?> constructor = cls.getConstructor();
			Object beanObj = constructor.newInstance();
			Object[] argArray = {/*strRunID,strLocatorName,strsubLocatorName,testSetName,strTestID,strBrowserType*/};
			Method method = cls.getMethod("QueueExecutionFromCmdLine",argArray.getClass());
			method.invoke(beanObj, new Object[] {argArray});

		} catch (MalformedURLException ex) {
			log.info("MalformedURLException: " + ex);
		} catch (ClassNotFoundException ex) {
			log.info("ClassNotFoundException: " + ex);
		} catch (NoSuchMethodException ex) {
			log.info("NoSuchMethodException: " + ex);
		} catch (SecurityException ex) {
			log.info("SecurityException: " + ex);
		} catch (InstantiationException ex) {
			log.info("InstantiationException: " + ex);
		} catch (IllegalAccessException ex) {
			log.info("IllegalAccessException: " + ex);
		} catch (IllegalArgumentException ex) {
			log.info("IllegalArgumentException: " + ex);
		} catch (InvocationTargetException ex) {
			System.err.println("An InvocationTargetException was caught!");
			Throwable cause = ex.getCause();
			System.out.format("Invocation of  failed because of: %s%n", cause.getMessage());
			log.info("InvocationTargetException: " + ex);
		}

	}
}
public class CallQueueClass {
	public static void main( String[] args )
	{		
		System.out.println("Entered in Queue class");
		String strProjDBname = args[0];
		String strLocator = args[1];
		String strSubLocator = args[2];
		String strTestSet = args[3];
		String strBrowserType = args[4];
		String strEmailSettingID = args[5];
		System.out.println("before");
		new QueueClass().create_queue(strProjDBname, strLocator, strSubLocator, strTestSet, strBrowserType, strEmailSettingID);
		System.out.println("after");
	}
}

package jos.queue.testset.execution;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * Hello world!
 *
 */
class QueueExecution {
	class WorkerThread implements Runnable {
		private org.apache.log4j.Logger log;
		String ProjectdbName, locator, sublocator, test_set, browsertype,
				email_setting;

		public WorkerThread(String dbNameTemp, String locatorTemp,
				String sublocatorTemp, String test_setTemp,
				String browsertypeTemp, String email_settingTemp) {
			this.ProjectdbName = dbNameTemp;
			this.locator = locatorTemp;
			this.sublocator = sublocatorTemp;
			this.test_set = test_setTemp;
			this.browsertype = browsertypeTemp;
			this.email_setting = email_settingTemp;
			log = Logger.getLogger(getClass());

		}

		public synchronized void run() {
			System.out.println(Thread.currentThread().getName() + " Started ");
			try {			
				String strFolderPath="";
				try {
					strFolderPath="file:\\" + new File (".").getCanonicalPath() + "\\J-SoS-Engine.jar";
				} catch (IOException e) {
					log.info("IOException: " + e.getMessage());
				}				
				strFolderPath=strFolderPath.replace("\\","/");
				System.out.println(strFolderPath);
				log.info("strFolderPath: " + strFolderPath);
				URL[] classLoaderUrls = new URL[] { new URL(strFolderPath) };
				@SuppressWarnings("resource")
				URLClassLoader urlClassLoader = new URLClassLoader(
						classLoaderUrls);
				Class<?> cls = urlClassLoader
						.loadClass("JoS.JAVAProjects.CommandLineExecution");
				Constructor<?> constructor = cls.getConstructor();
				Object beanObj = constructor.newInstance();
				Object[] argArray = { locator, sublocator, test_set,
						browsertype, email_setting, ProjectdbName};
				Method method = cls.getMethod("ExecuteForQueueSystem",
						argArray.getClass());
				method.invoke(beanObj, new Object[] { argArray });
			} catch (MalformedURLException ex) {
				log.info("MalformedURLException: " + ex);
			} catch (ClassNotFoundException ex) {
				log.info("ClassNotFoundException: " + ex);
			} catch (NoSuchMethodException ex) {
				log.info("NoSuchMethodException: " + ex);
			} catch (SecurityException ex) {
				log.info("SecurityException: " + ex);
			} catch (InstantiationException ex) {
				log.info("InstantiationException: " + ex);
			} catch (IllegalAccessException ex) {
				log.info("IllegalAccessException: " + ex);
			} catch (IllegalArgumentException ex) {
				log.info("IllegalArgumentException: " + ex);
			} catch (InvocationTargetException ex) {
				System.err.println("An InvocationTargetException was caught!");
				Throwable cause = ex.getCause();
				System.out.format("Invocation of  failed because of: %s%n",
						cause.getMessage());
				log.info("InvocationTargetException: " + ex);
			} catch (@SuppressWarnings("hiding") IOException e) {
				log.info("exception caught: " + e.getMessage());
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName() + " End.");
		}

		@Override
		public String toString() {
			return "";
		}
	}

	private Logger log = null;

	QueueExecution() {
		String log4jConfPath = "log4j.properties";
		PropertyConfigurator.configure(log4jConfPath);
		log = Logger.getLogger(getClass());
	}

	public synchronized void execute_queue() {
		log.info("Inside execute_queue");
		CheckDBForExecutionRequest();
	}

	private void CheckDBForExecutionRequest() {
		String id = null;
		String dbName = null;
		String locator = null;
		String sublocator = null;
		String test_set = null;
		String browsertype = null;
		String email_setting = null;
		DB_Handler con = new DB_Handler();
		while (true) {
			ResultSet rQueryExecReq = con.ExecuteSelectQuery("*",
					"current_execution_request;");
			try {
				if (rQueryExecReq.next()) {
					try {
						id = rQueryExecReq.getString("id");
						dbName = rQueryExecReq.getString("dbName");
						locator = rQueryExecReq.getString("locator");
						sublocator = rQueryExecReq.getString("sublocator");
						test_set = rQueryExecReq.getString("test_set");
						browsertype = rQueryExecReq.getString("browsertype");
						email_setting = rQueryExecReq
								.getString("email_setting");
					} catch (SQLException e) {
						log.info("exception caught: " + e);
						e.printStackTrace();
					}
					log.info("Request for ID: " + id);
					log.info("Calling CallJoSEngine()...");
					WorkerThread t = new WorkerThread(dbName, locator,
							sublocator, test_set, browsertype, email_setting);
					Thread t1 = new Thread(t);
					t1.start();
					t1.join();
					/*
					 * TestExecutionWorkerThread wt=new
					 * TestExecutionWorkerThread(jar_path, locator, sublocator,
					 * test_set,browsertype, email_setting); wt.execute();
					 */
					log.info("back from  CallJoSEngine()...");
					con.ExecuteDeleteQuery("current_execution_request where id = '"
							+ id + "';");
					rQueryExecReq = null;
				} else {
					con.ExecuteUpdateQuery("queue_execution_status SET Status='OFF';");
					break;
				}
			} catch (SQLException e) {
				log.info("exception caught: " + e.getMessage());
				e.printStackTrace();
				break;
			} catch (InterruptedException e) {
				log.info("exception caught: " + e.getMessage());
				e.printStackTrace();
				break;
			}
		}
	}
}

public class CallQueueExecution {
	public static void main(String[] args) {
		new QueueExecution().execute_queue();
	}

	public void QueueExecutionFromCmdLine(Object[] strObj) {
		new QueueExecution().execute_queue();

	}
}
